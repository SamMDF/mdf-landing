# La investigación detrás de la skill

Cada parte de la skill viene de una línea de investigación. Este archivo explica cuál y por qué, para que las decisiones del reporte se puedan defender. Revisado en octubre de 2026; las referencias marcadas como "secundaria" se verificaron en resúmenes y no en el texto original.

## Por qué hace falta un lector externo: la maldición del conocimiento

- **Fuente:** Camerer, Loewenstein y Weber (1989), *Journal of Political Economy*; experimento de los golpecitos de Elizabeth Newton, tesis doctoral en Stanford (1990).
- **Qué encontraron:** quien sabe algo no logra imaginar cómo lo percibe quien no lo sabe. En el experimento de Newton, quienes tamborileaban una canción conocida creían que el oyente la adivinaría alrededor de la mitad de las veces; en la práctica casi nadie la adivinó (las fuentes reportan cifras de 2.5% a 3 de 120 canciones).
- **En la skill:** justifica que el análisis lo haga un "lector" que no conoce el producto, y que se busque a la persona que menos sabe del tema en lugar del cliente promedio.

## La pregunta "¿entiende?": el recorrido cognitivo

- **Fuente:** Wharton, Rieman, Lewis y Polson (1994), "The Cognitive Walkthrough: A practitioner's guide", en Nielsen y Mack, *Usability Inspection Methods* (secundaria).
- **Qué propone:** evaluar si alguien que usa algo por primera vez (1) intenta lograr lo correcto, (2) nota que la acción está disponible, (3) la asocia con lo que quiere y (4) ve que avanzó. Se diseñó para sistemas de uso inmediato sin capacitación, como cajeros automáticos.
- **En la skill:** la pregunta "¿entiende?" y la instrucción de leer el texto en el orden en que la vería la persona, con una situación concreta.

## Cuánto desconfía: conocimiento de persuasión

- **Fuentes:** Friestad y Wright (1994), "The Persuasion Knowledge Model", *Journal of Consumer Research* 21(1); Obermiller y Spangenberg (1998), escala de escepticismo hacia la publicidad, *Journal of Consumer Psychology*.
- **Qué dicen:** las personas aprenden a reconocer cuándo y cómo las quieren persuadir, y responden defendiéndose. Las más escépticas tienden a no creer lo que dice un anuncio y a suponer intención de manipular. Trabajos posteriores encuentran que un mensaje creíble y transparente puede funcionar mejor justo con ellas.
- **En la skill:** la diferencia entre los tres clientes (el que tiene ganas, el que duda y el que no te cree), la instrucción de detectar dónde el texto "suena a venta", y que el que no te cree suponga que le quieren vender algo.

## La pregunta "¿te cree?": confianza inicial

- **Fuente:** McKnight, Choudhury y Kacmar (2002), "The impact of initial consumer trust on intentions to transact with a web site", *Journal of Strategic Information Systems* 11(3).
- **Qué dicen:** frente a alguien que no conoces, confías si crees que es capaz de cumplir, honesto y que busca tu bien, no solo el suyo. La reputación, la calidad que percibes y las garantías del entorno ayudan a formar esa confianza.
- **En la skill:** la pregunta "¿te cree?" (capaz, honesto, le importo) y la pregunta de qué le da seguridad.

## La pregunta "¿le conviene?": difusión de innovaciones

- **Fuente:** Everett Rogers, *Diffusion of Innovations* (5.ª ed., 2003).
- **Qué dice:** la gente adopta algo nuevo según cinco percepciones: que sea mejor que lo que reemplaza, que encaje con sus valores y su vida, que sea simple, que se pueda probar y que se vea funcionar en otros. Rogers reporta que estas percepciones explican entre 49% y 87% de la variación en la velocidad de adopción, con base en estudios de décadas atrás.
- **En la skill:** la pregunta "¿le conviene?" y la obligación de comparar contra lo que la persona hace hoy.

## Los límites: personas simuladas con IA

- **Fuentes:** Nielsen Norman Group, "Synthetic Users: If, When, and How to Use AI-Generated 'Research'" (secundaria); Bisbee y colegas (2024) y otros estudios sobre respuestas de encuesta generadas por modelos de lenguaje (secundaria).
- **Qué encontraron:** NN/g repitió tres estudios con usuarios simulados y encontró respuestas demasiado superficiales: elogiaban todos los conceptos y decían terminar cursos que la gente real abandona. Los estudios académicos encuentran respuestas más homogéneas y más complacientes que las humanas, y caricaturas cuando se simulan grupos específicos.
- **En la skill:** la sección "No seas amable", la regla de citar el texto en cada reacción, la advertencia contra estereotipos y el cierre que pide confirmar con cinco personas reales.

## Por qué cinco personas reales

Es la recomendación clásica de Jakob Nielsen ("Why You Only Need to Test with 5 Users", Nielsen Norman Group, 2000) para pruebas cualitativas de usabilidad: con cinco personas suelen aparecer la mayoría de los problemas graves. Sirve como siguiente paso práctico, no como garantía.
